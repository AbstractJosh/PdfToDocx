﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Windows;

namespace WpfChunkPdfToDocx
{
    public partial class ResultWindow : Window
    {
        private readonly string _docxPath;

        public ResultWindow(string docxPath)
        {
            InitializeComponent();
            _docxPath = docxPath;
            TxtPath.Text = docxPath;
        }

        private void OpenWord_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = _docxPath,
                    UseShellExecute = true
                };
                Process.Start(psi);
            }
            catch
            {
                var candidates = new[]
                {
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),     @"Microsoft Office\root\Office16\WINWORD.EXE"),
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Microsoft Office\root\Office16\WINWORD.EXE"),
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),     @"Microsoft Office\Office15\WINWORD.EXE"),
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Microsoft Office\Office15\WINWORD.EXE"),
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),     @"Microsoft Office\Office14\WINWORD.EXE"),
                    Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), @"Microsoft Office\Office14\WINWORD.EXE")
                };

                var winword = candidates.FirstOrDefault(File.Exists);
                if (!string.IsNullOrEmpty(winword))
                {
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = winword,
                        Arguments = $"\"{_docxPath}\"",
                        UseShellExecute = true
                    });
                }
                else
                {
                    MessageBox.Show(
                        "Couldn't open with Microsoft Word. The file was created successfully.\n\n" +
                        "Tip: Set Word as the default app for .docx, then use 'Open in Word' again.",
                        "Open in Word",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }

        private void OpenFolder_Click(object sender, RoutedEventArgs e)
        {
            if (File.Exists(_docxPath))
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = "explorer.exe",
                    Arguments = $"/select,\"{_docxPath}\"",
                    UseShellExecute = true
                });
            }
        }

        private void Close_Click(object sender, RoutedEventArgs e) => Close();
    }
}
