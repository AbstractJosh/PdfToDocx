﻿using System.Windows;

namespace WpfChunkPdfToDocx
{
    public partial class App : Application { }
}
