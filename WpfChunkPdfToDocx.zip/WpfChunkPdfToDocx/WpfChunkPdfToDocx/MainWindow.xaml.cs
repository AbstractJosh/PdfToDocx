﻿using Microsoft.Win32;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;

namespace WpfChunkPdfToDocx
{
    public partial class MainWindow : Window
    {
        public MainWindow() => InitializeComponent();

        private async void BtnSelect_Click(object sender, RoutedEventArgs e)
        {
            var ofd = new OpenFileDialog
            {
                Filter = "PDF files (*.pdf)|*.pdf",
                Title = "Select a PDF"
            };
            if (ofd.ShowDialog() != true) return;

            BtnSelect.IsEnabled = false;
            TxtStatus.Text = "Status: converting…";
            TxtLog.Clear();

            try
            {
                var inputPdfPath = ofd.FileName;
                var outputDocxPath = Path.Combine(
                    Path.GetDirectoryName(inputPdfPath)!,
                    Path.GetFileNameWithoutExtension(inputPdfPath) + "_converted.docx");

                await Task.Run(() =>
                {
                    using var pdfStream = new FileStream(inputPdfPath, FileMode.Open, FileAccess.Read);
                    // Depending on your Freeware.Pdf2Docx build, use either of these:
                    byte[] docxBytes = Freeware.Pdf2Docx.Convert(pdfStream); // common signature
                    File.WriteAllBytes(outputDocxPath, docxBytes);

                    // If yours is stream-out:
                    // using var ms = new MemoryStream();
                    // Freeware.Pdf2Docx.Convert(pdfStream, ms);
                    // File.WriteAllBytes(outputDocxPath, ms.ToArray());
                });

                TxtStatus.Text = $"Status: done → {outputDocxPath}";
                TxtLog.AppendText("✅ Conversion completed.\n");

                // NEW: show result window with open-in-Word option
                var result = new ResultWindow(outputDocxPath);
                result.Owner = this;
                result.WindowStartupLocation = WindowStartupLocation.CenterOwner;
                result.ShowDialog();
            }
            catch (Exception ex)
            {
                TxtStatus.Text = "Status: error";
                TxtLog.AppendText("❌ " + ex + Environment.NewLine);
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                BtnSelect.IsEnabled = true;
            }
        }
    }
}
